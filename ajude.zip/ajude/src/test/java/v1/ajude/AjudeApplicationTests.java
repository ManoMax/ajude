package v1.ajude;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AjudeApplicationTests {

	@Test
	void contextLoads() {
	}

}
